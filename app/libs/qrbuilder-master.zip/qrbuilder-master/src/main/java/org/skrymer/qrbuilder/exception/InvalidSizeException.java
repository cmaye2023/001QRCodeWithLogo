package org.skrymer.qrbuilder.exception;

public class InvalidSizeException extends RuntimeException {

  public InvalidSizeException(String message){
    super(message);
  }
}
